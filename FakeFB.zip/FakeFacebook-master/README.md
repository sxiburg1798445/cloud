# FakeFacebook
A phishing page for facebook. Only for showcase and educational purposes.
Posted on bookofface.000webhostapp.com 
