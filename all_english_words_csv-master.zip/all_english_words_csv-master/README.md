# all_english_words_csv
This CSV contains all the words in the English language.
